#!/bin/bash
echo "Hello from Cronium Runner!"
echo "Job ID: $CRONIUM_JOB_ID"
echo "Event ID: $CRONIUM_EVENT_ID"
