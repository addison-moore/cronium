#!/usr/bin/env python3
import os, json, sys

MESSAGE = "Hello World!"
outfile = "/root/test.txt"

with open(outfile, "w", encoding="utf-8") as f:
    f.write(MESSAGE)

print(f"[runner-test] Wrote {len(MESSAGE)} bytes to {outfile}")

# Optional: emit outputs.json for the orchestrator, if the runner exposes CRONIUM_OUTPUT_FILE
outputs_path = os.getenv("CRONIUM_OUTPUT_FILE")
if outputs_path:
    try:
        with open(outputs_path, "w", encoding="utf-8") as f:
            json.dump(
                {"outputs": {"file_path": outfile, "bytes_written": len(MESSAGE)}},
                f,
            )
    except Exception as e:
        print(f"[runner-test] Failed to write outputs file: {e}", file=sys.stderr)
