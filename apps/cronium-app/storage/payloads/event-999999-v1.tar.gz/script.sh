#!/bin/bash
echo "Hello from payload test!"
echo "Current time: $(date)"
echo "Environment variable TEST_VAR: $TEST_VAR"